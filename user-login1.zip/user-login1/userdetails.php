<?php
include 'db.php';
$decodedid=base64_decode($_GET['id']);
mysqli_select_db($_SESSION['connection'],'hobbyhub');
$query="select *from user where emailid='$decodedid'";
$execution=mysqli_query($_SESSION['connection'],$query);
$getarray=mysqli_fetch_array($execution);
?>
<!DOCTYPE html>
<html>
<head>
	<title>UserDetails</title>
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
</head>
<body>
<div class="container text-center">
	<h1>USER DETAILS</h1>
	<div class="row text-center">

		USERNAME:<b><?php echo $getarray['username'];?></b>
	</div>
	<br>
	<div class="row">

		USER-EMAIL:<b><?php echo $getarray['emailid'];?></b>
	</div>
	<br>
	<div class="row">
			USER-PASSWORD:
			<br>
			encrypting the password for security purpose
			<br>
			<b><?php echo md5($getarray['password'])?><b>
	</div>
	<div>

			<a href="properties.html" class="btn btn-success text-white">selection</a>
	</div>
</div>
</body>
</html>
