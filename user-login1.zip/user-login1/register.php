<?php
include 'db.php';
mysqli_select_db($_SESSION['connection'],'hobbyhub');
$message='';
if(isset($_POST['register'])){
	if($_POST['password']!=$_POST['confirm_password']){
		$message='<h1>re-entered password was wrong</h1>';
	}
	else{
	$email=$_POST['email'];
	$username=$_POST['username'];
	$password=$_POST['password'];

		$query="select *from user where emailid='$email'";
		$exc=mysqli_query($_SESSION['connection'],$query);
		$rows=mysqli_num_rows($exc);
		if($rows!=0){
			$message='<h2>record already exists</h2>';
		}
		else{
			$q1="insert into user(username,emailid,password)values('$username','$email','$password')";
			$exc1=mysqli_query($_SESSION['connection'],$q1);
			if($exc1){
				$message="<h1 style='color:green'>record has been added successfully</h1>";
				echo "<script>alert('congrats you are successfully signedUp')</script>";
			}

		}
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Register</title>
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  		<script>if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}</script>
</head>
<body>
<div class="container">
			<br />
			<h1>CRUD TASK</h1>
			
			<div class="panel panel-default">
  				<div class="panel-heading">HobbyHub</div>
				<div class="panel-body">
					<form method="post" action="">
					<div class="message"><?php echo $message; ?></div>
						<div class="form-group">
							<label>Enter Username</label>
							<input type="text" name="username" class="form-control" required/>
						</div>
						<div class="form-group">
								<label>Enter Email</label>
								<input type="email" name="email" class="form-control" required/>
						</div>
						<div class="form-group">
							<label>Enter Password</label>
							<input type="password" name="password" class="form-control" required/>
						</div>
						<div class="form-group">
							<label>Re-enter Password</label>
							<input type="password" name="confirm_password" class="form-control" required />
						</div>
						<div class="form-group">
							<input type="submit" name="register" class="btn btn-info" value="Register"/>
						</div>
						<div align="center">
							<a href="login.php">Login</a>
						</div>
					</form>
				</div>
			</div>
		</div>
</body>
</html>


	