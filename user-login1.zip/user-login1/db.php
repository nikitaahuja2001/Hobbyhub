<?php
	
	session_start();

	$con=mysqli_connect("localhost", "root");
	$_SESSION['connection']=$con;
	if(!$con){
		echo" connection unsuccessful";
	}
?>


