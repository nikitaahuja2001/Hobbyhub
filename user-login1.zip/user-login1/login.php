<?php
include 'db.php';
mysqli_select_db($_SESSION['connection'],'hobbyhub');
$message='';
if(isset($_POST['login'])){
	$email=$_POST['email'];
	$password=$_POST['password'];
	$query="select *from user where emailid='$email' and password='$password'";
	$execution=mysqli_query($_SESSION['connection'],$query);
	$rows=mysqli_num_rows($execution);
	if($rows==0){
		$message='<h1>Oops!No such record exists!!</h1>';
	}
	else{
		$message='<h2 style="color:green">navigating to your detail page</h2>';
		$id=base64_encode($email);
		header('Location:userdetails.php?id='.$id.'');
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>User Login Panel</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

</head>
<body>
	 <div class="container">
			<br />
			
			<h3 align="center">Login Panel</h3><br />
			<br />
			<div class="panel panel-default">
  				<div class="panel-heading" style="background:#128C7E;color:white">Login</div>
				<div class="panel-body">
					<p class="text-danger"><?php $message;?></p>
					<form method="post">
						<div class="form-group">
							<label>Enter Email</label>
							<input type="text" name="email" class="form-control" required />
						</div>
						<div class="form-group">
							<label>Enter Password</label>
							<input type="password" name="password" class="form-control" required />
						</div>
						<div class="form-group">
							<input type="submit" name="login" class="btn btn-success" value="Login" />
						</div>
						<div align="center">
							<a href="register.php">Don't have an account?<h2 class="text-success">Register</h2></a>
						</div>
					</form>
					<br />
					<br />
					<br />
					<br />
				</div>
			</div>
		</div>

</body>
</html>